import CafeLoginPage from './components/CafeLoginPage'

export default function App() {
  return <CafeLoginPage />
}
