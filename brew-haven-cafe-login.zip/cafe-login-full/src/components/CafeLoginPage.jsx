export default function CafeLoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1974&auto=format&fit=crop')] bg-cover bg-center px-4">
      <div className="absolute inset-0 bg-black/50"></div>

      <div className="relative w-full max-w-md bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/20 p-8 text-white">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-wide">Brew Haven</h1>
          <p className="text-gray-200 mt-2">
            Welcome back to your favorite cafe ☕
          </p>
        </div>

        <form className="space-y-5">
          <div>
            <label className="block mb-2 text-sm font-medium">
              Email Address
            </label>

            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-2xl bg-white/20 border border-white/30 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>

          <div>
            <label className="block mb-2 text-sm font-medium">
              Password
            </label>

            <input
              type="password"
              placeholder="Enter your password"
              className="w-full px-4 py-3 rounded-2xl bg-white/20 border border-white/30 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded" />
              Remember me
            </label>

            <a href="#" className="text-amber-300 hover:underline">
              Forgot Password?
            </a>
          </div>

          <button
            type="submit"
            className="w-full bg-amber-500 hover:bg-amber-600 transition-all duration-300 py-3 rounded-2xl font-semibold shadow-lg"
          >
            Login
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-200">
          Don’t have an account?{" "}
          <a href="#" className="text-amber-300 hover:underline font-medium">
            Sign Up
          </a>
        </div>

        <div className="mt-8 border-t border-white/20 pt-5 text-center text-xs text-gray-300">
          © 2026 Brew Haven Cafe. Fresh Coffee, Cozy Moments.
        </div>
      </div>
    </div>
  )
}
