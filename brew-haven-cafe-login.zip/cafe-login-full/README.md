# Brew Haven Cafe Login

## Install dependencies

npm install

## Start development server

npm run dev

## Build production

npm run build
